# uninstall pack

