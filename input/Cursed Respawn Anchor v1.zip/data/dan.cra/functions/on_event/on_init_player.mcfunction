# init players

#if cursed respawn anchor is not set
execute positioned ~ ~ ~ in minecraft:the_nether unless entity @e[type=minecraft:armor_stand,tag=dan.cra_CRA] as @s run function dan.cra:spawn_cra

#take player to Cursed Respawn Anchor
execute in minecraft:the_nether as @s at @e[type=minecraft:armor_stand,tag=dan.cra_CRA] positioned ~ ~1.188 ~ run tp ~ ~1 ~

#set spawnpoint
execute in minecraft:the_nether as @s at @e[type=minecraft:armor_stand,tag=dan.cra_CRA] positioned ~ ~1.188 ~ run spawnpoint @s ~ ~1 ~

#tag player
tag @s add dan.cra_init_player