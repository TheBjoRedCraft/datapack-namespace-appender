# runs every load/reload

#debug command (required)
minecraft:scoreboard objectives add dan.debug dummy

##on reload
#count reloads
minecraft:scoreboard players add $CRAReloadCount dan.debug 1

##on first load
#install (runs once on first install)
minecraft:execute if score $CRAReloadCount dan.debug matches 1 run function dan.cra:on_event/on_install

#begin loops
minecraft:schedule function dan.cra:loop/main 1t replace
minecraft:schedule function dan.cra:loop/per_10_ticks 1t replace