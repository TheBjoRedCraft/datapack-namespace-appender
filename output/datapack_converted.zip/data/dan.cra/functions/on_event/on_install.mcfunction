# runs once on first reload

#detects when the Obsidian block is broken
minecraft:scoreboard objectives add dan.cra_mineObsi minecraft.mined:minecraft.obsidian