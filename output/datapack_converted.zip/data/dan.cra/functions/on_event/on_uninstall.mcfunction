# uninstall pack

