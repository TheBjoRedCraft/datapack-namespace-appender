# kills Cursed Respawn Anchor when it is detected that it was broken

#kills obsidian item (broken Cursed Respawn Anchor block item)
minecraft:kill @e[type=minecraft:item,tag=dan.item_obsidian,sort=nearest,limit=1]

#reset spawnpoint for players
minecraft:execute positioned ~ ~ ~ in minecraft:overworld run spawnpoint @a ~ ~ ~

#set Cursed Respawn Anchor global broken score to true
minecraft:scoreboard players set $CRABroken dan.debug 1

#play sound
minecraft:playsound minecraft:ambient.nether_wastes.mood block @a ~ ~ ~ 1.2 2
minecraft:playsound minecraft:entity.ender_dragon.growl block @a ~ ~ ~ 1.2 .2

#particles
minecraft:particle dust 1.0 0 0 1.0 ~ ~ ~ 0.5 0.5 0.5 1 50

#kills self
minecraft:kill @s