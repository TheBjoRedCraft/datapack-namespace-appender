# detect item entity nbt

#obsidian
minecraft:execute if data entity @s[tag=!dan.item_obsidian] {Item:{id:"minecraft:obsidian"}} run tag @s add dan.item_obsidian

#tag
minecraft:tag @s add dan.cra_item_nbt_tagged